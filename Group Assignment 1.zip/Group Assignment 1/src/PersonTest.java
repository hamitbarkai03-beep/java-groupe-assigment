// PersonTest.java
// This class tests the Person class

public class PersonTest {

    public static void main(String[] args) {

        // Create first Person
        Person p1 = new Person();
        p1.name = "Alice";
        p1.age = 25;
        p1.city = "New York";
        p1.height = 1.65;
        Person.totalPeople++;

        // Create second Person
        Person p2 = new Person();
        p2.name = "Bob";
        p2.age = 30;
        p2.city = "London";
        p2.height = 1.75;
        Person.totalPeople++;

        // Create third Person
        Person p3 = new Person();
        p3.name = "Charlie";
        p3.age = 22;
        p3.city = "Paris";
        p3.height = 0.0;
        Person.totalPeople++;

        // Display information
        p1.displayInfo();
        p2.displayInfo();
        p3.displayInfo();

        // Test setHeight method
        System.out.println("--- Setting Heights ---");
        p1.setHeight(1.68);
        p2.setHeight(1.82);

        // Test haveBirthday method
        System.out.println("\n--- Birthday Time! ---");
        p1.haveBirthday();

        // Create 5 more people using a loop
        System.out.println("\n--- Creating 5 more people ---");

        for (int i = 1; i <= 5; i++) {
            Person p = new Person();
            p.name = "Person" + i;
            p.age = 20 + i;
            p.city = "City" + i;
            p.height = 1.70;
            Person.totalPeople++;

            p.displayInfo();
        }

        // Display total number of people
        Person.showTotalPeople();
    }
}

