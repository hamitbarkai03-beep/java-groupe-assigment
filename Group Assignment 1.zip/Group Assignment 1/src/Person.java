// Person.java
// This class represents a Person with basic information

public class Person {

    // Instance variables
    String name;
    int age;
    String city;
    double height;

    // Static variable (shared by all Person objects)
    static int totalPeople = 0;

    // Method to display person information
    void displayInfo() {
        System.out.println("=== Person Information ===");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("City: " + city);
        System.out.println("Height: " + height + " m");
        System.out.println();
    }

    // Method to set height using a local variable
    void setHeight(double h) {
        double oldHeight = height; // local variable
        height = h;
        System.out.println("Height changed from " + oldHeight + " to " + height + " m");
    }

    // Method to increase age by 1
    void haveBirthday() {
        age = age + 1;
        System.out.println(name + " had a birthday! Now " + age + " years old.");
    }

    // Static method to show total people created
    static void showTotalPeople() {
        System.out.println("Total people created: " + totalPeople);
    }
}
